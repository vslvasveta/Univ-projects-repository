
Hello! In the zip you can find the code of the programm for hiding the 
message into the image using the method of Least Significant Bit Stenography.

The list of used packages:

cv2 (opencv-python) v. 4.6.0.66
docopt v. 0.6.2
numpy v. 1.23.5

IDE: PyCharm Community Edition 2021.2.2, Python 3.10.0

There are also examples of images for you to try to decode my messages :)
And png version of README.

Good luck for you in rabbit year!
